import React from "react";
import { ModeToggle } from "../../../_components/ThemeToggle/theme-toggle";
import { UserNav } from "./user-nav";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import { Breadcrumbs } from "@/components/breadcrumbs";
import SearchInput from "@/components/search-input";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { IconBrowser } from "@tabler/icons-react";

export default function Header() {
  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-2 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12">
      <div className="flex items-center gap-2 px-4">
        <SidebarTrigger className="-ml-1" />
        <Separator orientation="vertical" className="mr-2 h-4" />
        <Breadcrumbs />
      </div>

      <div className="flex items-center gap-4 px-4">
        <Button variant='soft' asChild>
          <Link href="/" target="_blank">
          <IconBrowser />
            View Site
          </Link>
        </Button>
        <div className="hidden md:flex">
          <SearchInput />
        </div>
        <ModeToggle />
        <UserNav />
      </div>
    </header>
  );
}
