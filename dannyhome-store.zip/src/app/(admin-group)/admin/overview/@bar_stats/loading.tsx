// import { BarGraphSkeleton } from '@/features/overview/components/bar-graph-skeleton';

import { BarGraphSkeleton } from "@/app/(admin-group)/admin/overview/_components/bar-graph-skeleton";

export default function Loading() {
  return <BarGraphSkeleton />;
}
