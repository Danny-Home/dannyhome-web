import HeroBannerCarousel from "@/app/_components/hero-banner-carousel";
import { HydrateClient } from "@/trpc/server";

export default async function Home() {
  return (
    <HydrateClient>
      <main className="flex min-h-screen flex-col items-center justify-center">
        <HeroBannerCarousel />
      </main>
    </HydrateClient>
  );
}
