
'use client'
import { api } from '@/trpc/react'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
export function AddToCart({ id, price }: { id: string; price: number }){
  const m = api.cart.addItem.useMutation({ onSuccess(){ toast('Añadido al carrito') }})
  return <Button onClick={() => m.mutate({ variantId: id as any, quantity: 1, unitPrice: price, currency: 'BRL' })} className="rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground">Añadir al carrito</Button>
}

import Image from "next/image";
import dynamic from "next/dynamic";
import { notFound } from "next/navigation";
import { trpc } from "@/trpc/server";

const ProductCarousel = dynamic(() => import("../../_components/product-carousel"), { ssr: false });

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await trpc.products.bySlug({ slug: params.slug }).catch(() => null);
  if (!product) return notFound();

  const imgs = (product as any).attachments ?? [];
  const img = imgs[0]?.url ?? "/placeholder.svg";

  return (
    <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <div>
          <div className="aspect-square overflow-hidden rounded-xl border bg-muted">
            <Image src={img} alt={(product as any).name} width={900} height={900} className="h-full w-full object-cover" unoptimized />
          </div>
          {imgs.length > 1 && (
            <div className="mt-3 grid grid-cols-4 gap-3">
              {imgs.slice(0,8).map((a: any) => (
                <Image key={a.id} src={a.url} alt="" width={200} height={200} className="aspect-square rounded-md object-cover" unoptimized />
              ))}
            </div>
          )}
        </div>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-semibold">{(product as any).name}</h1>
            <p className="mt-2 text-xl font-bold">
              {new Intl.NumberFormat("es-ES", { style: "currency", currency: "BRL" }).format(Number((product as any).price))}
            </p>
          </div>
          <p className="text-sm text-muted-foreground">{(product as any).description}</p>
          <div className="grid grid-cols-2 gap-3">
            {/* @ts-expect-error Server Component compile boundary */}
<AddToCart id={(product as any).id} price={Number((product as any).price)} />
            <button className="rounded-md border px-4 py-2 text-sm">Comprar ahora</button>
          </div>
          <div className="rounded-xl border p-4">
            <h3 className="font-medium">Detalles</h3>
            <dl className="mt-2 grid grid-cols-2 gap-2 text-sm">
              <div><dt className="text-muted-foreground">Stock</dt><dd>En stock</dd></div>
              <div><dt className="text-muted-foreground">Envío</dt><dd>24-72h</dd></div>
            </dl>
          </div>
        </div>
      </div>

      <div className="mt-12">
        {/* Placeholder related section */}
      </div>
    </div>
  );
}
