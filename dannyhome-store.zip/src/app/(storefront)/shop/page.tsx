import dynamic from "next/dynamic";
import { trpc } from "@/trpc/server";
import ProductCard from "../_components/product-card";

const FiltersSidebar = dynamic(() => import("../_components/filters-sidebar"), { ssr: false });

export default async function CatalogPage() {
  const [{ products }, { categories }] = await Promise.all([
    trpc.products.publicList({ showAll: true, page: 1, perPage: 48 }),
    trpc.categories.publicList({ showAll: true, page: 1, perPage: 100 }),
  ]);

  return (
    <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 rounded-xl bg-muted/40 p-6 text-center">
        <h1 className="text-2xl font-semibold">Catálogo</h1>
        <p className="mt-2 text-muted-foreground">Encuentra tu próximo favorito</p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-12">
        <div className="md:col-span-3">
          <FiltersSidebar
            categories={categories as any}
            onChange={() => {}}
          />
        </div>
        <div className="md:col-span-9">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {products.map((p: any) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
