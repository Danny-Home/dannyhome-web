import type { ReactNode } from "react";
import dynamic from "next/dynamic";

const Header = dynamic(() => import("@/app/_components/header"), { ssr: true });
const Footer = dynamic(() => import("./_components/footer"), { ssr: true });

export default function StorefrontLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-dvh flex flex-col">
      {/* Header */}
      <Header />
      {/* Main */}
      <main className="flex-1">{children}</main>
      {/* Footer */}
      <Footer />
    </div>
  );
}