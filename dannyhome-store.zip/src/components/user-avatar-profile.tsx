import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { User } from 'prisma/interfaces';

interface UserAvatarProfileProps {
  className?: string;
  showInfo?: boolean;
  user: User & {id: string} | null;
}

export function UserAvatarProfile({
  className,
  showInfo = false,
  user
}: UserAvatarProfileProps) {
  return (
    <div className='flex items-center gap-2'>
      <Avatar className={className}>
        <AvatarImage src={user?.image ?? ''} alt={user?.name ?? ''} />
        <AvatarFallback className='rounded-lg h-12 w-12'>
          {user?.name?.slice(0, 2)?.toUpperCase() ?? 'CN'}
        </AvatarFallback>
      </Avatar>

      {showInfo && (
        <div className='grid flex-1 text-left text-sm leading-tight'>
          <span className='truncate font-semibold'>{user?.name ?? ''}</span>
          <span className='truncate text-xs'>
            {user?.email ?? ''}
          </span>
        </div>
      )}
    </div>
  );
}
