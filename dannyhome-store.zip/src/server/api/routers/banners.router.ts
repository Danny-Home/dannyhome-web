import { createBannerSchema, updateBannerSchema } from "@/lib/schemas/banner";
import { adminProcedure, createTRPCRouter, publicProcedure } from "../trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

export const bannersRouter = createTRPCRouter({
  listActive: publicProcedure.query(async ({ ctx }) => {
    const now = new Date();
    const banners = await ctx.db.banner.findMany({
      where: {
        active: true,
        OR: [{ startsAt: null }, { startsAt: { lte: now } }],
        AND: [{ endsAt: null }, { endsAt: { gte: now } }],
      },
      orderBy: { order: "asc" },
    });
    return banners;
  }),
});
